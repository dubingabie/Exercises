#################################################################
# FILE : hangman.py
# WRITER : Gaberiel Dubin , dubingabie , 209386481
# EXERCISE : intro2cse ex4 2021
# DESCRIPTION:
# STUDENTS I DISCUSSED THE EXERCISE WITH:
# WEB PAGES I USED:
# NOTES: ...
#################################################################
import hangman_helper as helper


# pattern management
def letter_location(word, letter):
    """ a functions that finds all of the appearances of a char in a string
        :param : a string and a char
        :return : a list that contains the indexes of all of the appearances of that char in the string"""
    word = list(word)
    letter_location_list = list()
    for i in range(len(word)):
        if word[i] == letter:
            letter_location_list.append(i)
    return letter_location_list


def update_word_pattern(word, pattern, letter):
    """ a function that updates the hangman pattern according to the users lguess
        :param : a string containing a word
                 a string containg the hangman pattern
                 a char containg the guessed letter
        :return : the updated hangman pattern"""
    update_list = letter_location(word, letter)
    for i in range(len(update_list)):
        pattern = pattern[:update_list[i]] + letter + pattern[update_list[i]+1:]
    return pattern


# input management


def calculate_score_addition(letter_appearance):
    """ a function that calculates the addition to the user's score after a correct guess
        :param : receives the amount of times the letters the user has guessed appear in the word
        :returns : returns the ammount of points that should be added to the users score"""
    return (letter_appearance*(letter_appearance+1)) // 2


def letter_guess(letter_input, score, word, pattern, wrong_guess_list):
    output_message = ""
    if len(letter_input) != 1 or ord(letter_input) not in range(97, 122):
        output_message = "The letter you entered is invalid."
    elif letter_input in wrong_guess_list or letter_input in pattern:
        output_message = "The letter you entered was already chosen."
    else:
        updated_pattern = update_word_pattern(word, pattern, letter_input)
        score -= 1
        if pattern != updated_pattern:
            letter_appearance = pattern.count("_") - updated_pattern.count("_")
            score += calculate_score_addition(letter_appearance)
            pattern = updated_pattern
        else:
            wrong_guess_list.append(letter_input)
    return pattern, score, wrong_guess_list, output_message


def word_guess(word_input, word, pattern, score):
    score -= 1
    if word_input == word:
        letter_appearance = pattern.count("_")
        score += calculate_score_addition(letter_appearance)
        pattern = word
    return pattern, score


def get_hints(word_list, pattern, wrong_guess_list, score):
    score -= 1
    hints_list = filter_words_list(word_list, pattern, wrong_guess_list)
    if len(hints_list) > helper.HINT_LENGTH:
        hints_list = hints_list[:helper.HINT_LENGTH]
    helper.show_suggestions(hints_list)
    return score


def input_manager(user_input, score, word, pattern, wrong_guess_list, word_list):
    output_message = ""
    if user_input[0] == helper.LETTER:
        pattern, score, wrong_guess_list, output_message = letter_guess(user_input[1], score, word, pattern, wrong_guess_list)
    elif user_input[0] == helper.WORD:
        pattern, score = word_guess(user_input[1], word, pattern, score)
    elif user_input[0] == helper.HINT:
        score = get_hints(word_list, pattern, wrong_guess_list, score)
    return score, pattern, wrong_guess_list, output_message


def endgame_manager(pattern, score, word, wrong_guess_list):
    end_message = "congratulations! you have guessed the word correctly" # צריך להוסיף הודעה מתתאימה
    if pattern.count("_") > 0:
        end_message = f'you have lost the game. the word was {word}' #צריך להוסיף הודעה מתאימה
    helper.display_state(pattern, wrong_guess_list, score, end_message)


def run_single_game(word_list, score):
    word = helper.get_random_word(word_list)
    pattern = "_" * len(word)
    wrong_guess_list = list()
    output_message = ""
    while score > 0 and pattern != word:
        helper.display_state(pattern, wrong_guess_list, score, output_message)
        user_input = helper.get_input()
        score, pattern, wrong_guess_list, output_message =\
            input_manager(user_input, score, word, pattern, wrong_guess_list, word_list)
    endgame_manager(pattern, score, word, wrong_guess_list)
    return score


# def main():
#     word_list = helper.load_words()
#     num_of_games = 1
#     score = run_single_game(word_list, helper.POINTS_INITIAL)
#     keep_playing = helper.play_again(f'you have played {num_of_games} games and your current score is {score}')
#     while keep_playing:
#         if score > 0:
#             run_single_game(word_list, score)
#             num_of_games += 1
#         else:
#             run_single_game(word_list, helper.POINTS_INITIAL)

def determine_play_again_message(score, num_of_games):
    play_again_message = f'Number of games survived: {num_of_games}. Start a new series of games?"'
    if score > 0:
        play_again_message = f'Number of games so far: {num_of_games}. Your current score: {score}. Want to continue?'
    return play_again_message


def main():
    word_list = helper.load_words()
    num_of_games = 1
    score = run_single_game(word_list, helper.POINTS_INITIAL)
    while helper.play_again(determine_play_again_message(score, num_of_games)):
        if score > 0:
            run_single_game(word_list, score)
            num_of_games += 1
        else:
            run_single_game(word_list, helper.POINTS_INITIAL)



def filter_word_length(words_list, pattern):
    filtered_list = list()
    for i in range(len(words_list)):
        if len(words_list[i]) == len(pattern):
            filtered_list.append(words_list[i])
    return filtered_list


def filter_wrong_letter_words(word_list, wrong_guess_list):
    filtered_list = list()
    wrong_guess_set = set(wrong_guess_list)
    for i in range(len(word_list)):
        if not bool(set(word_list[i]) & wrong_guess_set):
            filtered_list.append(word_list[i])
    return filtered_list


def get_letters_in_pattern(pattern):
    letter_location_list = list()
    for i in range(len(pattern)):
        if pattern[i] != "_":
            letter_location_list.append(i)
    return letter_location_list


def does_have_pattern_letters_in_word(letter_location_list, word, pattern):
    for i in range(len(letter_location_list)):
        if word.count(pattern[letter_location_list[i]]) != pattern.count(pattern[letter_location_list[i]]):
            return False
    return True


def is_compatible_word(letter_location_list, word, pattern):
    for i in range(len(letter_location_list)):
        if pattern[letter_location_list[i]] != word[letter_location_list[i]]:
            return False
    return True


def filter_words_by_pattern(words_list, pattern):
    filtered_list = list()
    letter_location_list = get_letters_in_pattern(pattern)
    for i in range(len(words_list)):
        if is_compatible_word(letter_location_list, words_list[i], pattern):
            if does_have_pattern_letters_in_word(letter_location_list, words_list[i], pattern):
                filtered_list.append(words_list[i])
    return filtered_list


def filter_words_list(words_list, pattern, wrong_guess_list):
    hints_list = filter_word_length(words_list, pattern)
    hints_list = filter_wrong_letter_words(hints_list, wrong_guess_list)
    hints_list = filter_words_by_pattern(hints_list, pattern)
    return hints_list


if __name__ == "__main__":
    main()