from code_1 import *


def test_fizzBuz_1():
    assert fizzBuzz_1(3) == "Fizz"
    assert fizzBuzz_1(5) == "Buzz"
    assert fizzBuzz_1(15) == "FizzBuzz"
    assert fizzBuzz_1(13) == 13
