#################################################################
# FILE : additional_file.py
# WRITER : Gaberiel Dubin, dubingabie , 209386481
# EXERCISE : intro2cse ex1 2021
# DESCRIPTION: prints out the secret string in the pre submission script
# STUDENTS I DISCUSSED THE EXERCISE WITH:
# WEB PAGES I USED:
# NOTES: ...
#################################################################

def secret_function():
    print("My username is dubingabie and I know I must read the submission response.")

